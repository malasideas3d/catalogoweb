import flet as ft
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import os
import time
import asyncio

# --- Estructura de datos para la configuración ---
class AppConfig:
    """Clase para almacenar los datos de configuración de la app."""
    def __init__(self):
        self.cLogoEmpresa = "/media/logo.png"
        self.cFondoEmpresa = "/media/fondo.jpg"
        self.cIconEmpresa = "/media/icon.ico"
        self.tamanologo = 100
        
        self.cNombreEmpresa = ""
        self.cNombrePagina = ""
        self.cColoresEmpresa = ""
        self.cRedesSociales = ""
        self.cWhatsapp = ""
        self.cTelefono = ""
        self.cEmail = ""
        self.cDireccion = ""
        self.cSlogan = ""
        self.cTerminosCondiciones = ""

app_config = AppConfig()

# --- Funciones para las áreas de la interfaz ---

def create_header(page):
    # El header contendrá el logo, nombre de la empresa y redes sociales
    # Contenedor para las redes sociales (apiladas)
    social_icons_row = ft.Row(
        [
            # Reemplaza con los iconos de tus redes sociales
            #ft.IconButton(icon=ft.Icons.WHATSAPP, url=f"https://wa.me/{app_config.cWhatsapp}", icon_color = app_config.cColorEmp03),
            ft.IconButton(
                content=ft.Image(
                    src="https://cdn-icons-png.flaticon.com/512/124/124010.png",  # Ejemplo WhatsApp
                    width=30,
                    height=30,
                    fit=ft.ImageFit.CONTAIN
                ),
                on_click=lambda e: print("WhatsApp clickeado")
            ),
            ft.IconButton(icon=ft.Icons.FACEBOOK, url="https://facebook.com", icon_color = app_config.cColorEmp03),
            ft.IconButton(icon=ft.Icons.TIKTOK, url="https://twitter.com", icon_color = app_config.cColorEmp03),
            ft.IconButton(icon=ft.Icons.TELEGRAM, url="https://instagram.com", icon_color = app_config.cColorEmp03),
        ],
        spacing=0, # Espacio entre los iconos
        alignment=ft.MainAxisAlignment.CENTER
    )

    return ft.Container(
        content=ft.Row(
            [
                # Bloque izquierdo: Imagen del logo
                ft.Image(
                    src="/media/logo.png",
                    width=50,
                    height=50,
                    fit=ft.ImageFit.CONTAIN,
                ),
                
                # Bloque central: Nombre de la empresa
                ft.Text(
                    app_config.cNombrePagina + " - " + app_config.cNombreEmpresa,
                    size=20,
                    weight=ft.FontWeight.BOLD,
                    text_align=ft.TextAlign.CENTER,
                    color = app_config.cColorEmp04,
                    expand=True # Permite que el texto ocupe el espacio restante
                ),
                
                # Bloque derecho: Redes sociales apiladas
                social_icons_row,
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN, # Distribuye el espacio de manera uniforme
            vertical_alignment=ft.CrossAxisAlignment.CENTER
        ),
        padding=ft.padding.only(left=10, right=10, top=10, bottom=10),
        bgcolor=ft.Colors.with_opacity(1, app_config.cColorEmp01) # Ejemplo de color

    )

def create_body(page):
    # El cuerpo contendrá el catálogo de productos
    # Usaremos ResponsiveRow para que se ajuste a 1 o 2 columnas.
    return ft.Container(
        content=ft.ResponsiveRow(
            # Aquí irán los productos del catálogo.
            # Por ahora, un placeholder.
            [ft.Text("Aquí irá el catálogo de productos.", size=24)],
            spacing=10,
            run_spacing=10
        ),
        expand=True,
        padding=10
    )

def create_footer(page):
    # El pie de página contendrá información de contacto y términos y condiciones.
    def show_terms_dialog(e):
        page.dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("Términos y Condiciones"),
            content=ft.Text(app_config.cTerminosCondiciones),
            actions=[ft.TextButton("Cerrar", on_click=lambda e: page.close_dialog(e))],
        )
        page.dialog.open = True
        page.update()

    return ft.Container(
        content=ft.Row(
            [
                ft.Text(app_config.cSlogan, size=14, color=ft.Colors.WHITE),
                ft.TextButton("Términos y Condiciones", on_click=show_terms_dialog, style=ft.ButtonStyle(color=ft.Colors.WHITE)),
                ft.Text(f"Email: {app_config.cEmail}", size=12, color=ft.Colors.WHITE),
                ft.Text(f"Dirección: {app_config.cDireccion}", size=12, color=ft.Colors.WHITE)
            ],
            alignment=ft.MainAxisAlignment.SPACE_AROUND,
            vertical_alignment=ft.CrossAxisAlignment.CENTER
        ),
        padding=10,
        bgcolor=ft.Colors.with_opacity(0.8, app_config.cColorEmp02)
    )

# --- Función para leer los datos de Google Sheets de forma asíncrona ---
async def load_config_data():
    """Carga de forma asíncrona los datos de la hoja de Google Sheets 'Configuracion'."""
    try:
        scope = ['https://www.googleapis.com/auth/spreadsheets.readonly', 'https://www.googleapis.com/auth/drive.readonly']
        creds_path = "src/proyectocatalogo-08a1144f66db.json"
        
        # Verifica si el archivo de credenciales existe
        if not os.path.exists(creds_path):
            print(f"Error: No se encontró el archivo de credenciales '{creds_path}'.")
            return

        creds = ServiceAccountCredentials.from_json_keyfile_name(creds_path, scope)
        client = gspread.authorize(creds)
        
        # Abre la hoja de cálculo por su nombre o URL
        sheet_url = "https://docs.google.com/spreadsheets/d/1eWp23FwcH1fKGnhEByq90lnOS1xJS1BA2Mt59LWfG4o/edit?gid=0#gid=0" # Reemplaza con la URL de tu hoja
        sheet = client.open_by_url(sheet_url).worksheet('Configuracion')
        
        # Lee la primera fila (encabezados) y la segunda (datos)
        headers = sheet.row_values(1)
        values = sheet.row_values(2)
        
        # Asigna los valores a la clase AppConfig
        for i, header in enumerate(headers):
            if header == "cColoresEmpresa":
                colors = values[i].split('|')
                app_config.cColoresEmpresa = colors
                if len(colors) >= 4:
                    app_config.cColorEmp01 = "#" + colors[0]
                    app_config.cColorEmp02 = "#" + colors[1]
                    app_config.cColorEmp03 = "#" + colors[2]
                    app_config.cColorEmp04 = "#" + colors[3]
                print(app_config.cColorEmp01, app_config.cColorEmp02, app_config.cColorEmp03, app_config.cColorEmp04)
            elif header == "cRedesSociales":
                socials = values[i].split('|')
                app_config.cRedesSociales = {s.split('=')[0]: s.split('=')[1] for s in socials}
            else:
                setattr(app_config, header, values[i])
                print(header," = ", values[i])
        print("Datos de configuración cargados exitosamente.\n")
        for red_social, username in app_config.cRedesSociales.items():
            print(f"{red_social} = {username}")
    except Exception as e:
        print(f"Ocurrió un error al cargar la configuración: {e}")

# --- Función principal de la aplicación con Flet ---
async def main(page: ft.Page):
    # Configura la página para el splash screen
    page.title = "Cargando..."
    page.window_width = 800
    page.window_height = 600
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.theme_mode = ft.ThemeMode.SYSTEM

    # Vista de carga (splash screen)
    loading_screen = ft.Column(
        [
            ft.Image(
                src=app_config.cLogoEmpresa,
                width=app_config.tamanologo,
                height=app_config.tamanologo,
                fit=ft.ImageFit.CONTAIN,
            ),
            ft.ProgressBar(width=400, color=ft.Colors.BLUE, bgcolor="#eeeeee"),
            ft.Text("Cargando...", size=16)
        ],
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=20
    )
    page.add(loading_screen)
    #await asyncio.sleep(0.01) #desactivar TEMPORALMENTE
    page.update()
    # Inicia la carga de datos de forma asíncrona
    await load_config_data()
     # Una vez que la carga esté completa, muestra la interfaz principal
    page.clean()
    page.title = app_config.cNombrePagina + " - " + app_config.cNombreEmpresa
    page.favicon = app_config.cIconEmpresa
    page.theme = ft.Theme(color_scheme_seed=app_config.cColorEmp01)

    page.bgcolor = ft.Colors.TRANSPARENT
    page.decoration = ft.BoxDecoration(
        image=ft.DecorationImage(
            src=app_config.cFondoEmpresa,
            fit=ft.ImageFit.COVER,
            opacity=0.5,
        ),
        gradient=ft.LinearGradient(
            colors=[app_config.cColorEmp01, app_config.cColorEmp04],
            stops=[0, 1],
            begin=ft.alignment.top_left,
            end=ft.alignment.bottom_right,
        ),
    )

    # Contenedor principal con la imagen de fondo
    main_container = ft.Container(
        content=ft.Column(
            [
                create_header(page),
                create_body(page),
                create_footer(page)
            ],
            expand=True,
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN
        ),
        image=ft.Image(
            src=app_config.cFondoEmpresa,
            fit=ft.ImageFit.COVER
        ),
        expand=True
    )
    print(app_config.cFondoEmpresa)
    page.add(main_container)
    page.update()

# --- Configuración de la aplicación Flet ---
ft.app(target=main, assets_dir="src/assets")